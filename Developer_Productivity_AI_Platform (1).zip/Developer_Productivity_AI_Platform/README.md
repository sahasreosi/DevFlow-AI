# Developer Productivity & AI Project Management Platform

Full-stack submission covering:
1. Developer Productivity Dashboard
2. Users, Projects & Tasks REST API
3. Persistent Data Layer
4. AI-Powered Project & Task Management Platform

Stack: React + Vite, Node.js + Express, MongoDB + Mongoose, optional OpenAI integration.

## Run
Backend:
```bash
cd backend
npm install
cp .env.example .env
npm run dev
```

Frontend:
```bash
cd frontend
npm install
npm run dev
```

Backend: http://localhost:5000
Frontend: http://localhost:5173

If MongoDB is unavailable, the API uses an in-memory fallback so the demo remains runnable.
Set OPENAI_API_KEY in backend/.env for live AI responses.
